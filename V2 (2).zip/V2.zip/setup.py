import os
import datetime
import time
c = input("Choose your environment: [0] pip / [1] pip3 : ")

if c == "0":
    os.system("pip install cloudscraper")
    os.system("pip install socks")
    os.system("pip install pysocks")
    os.system("pip install colorama")
    os.system("pip install httpx")
    os.system("pip install undetected_chromedriver")
elif c == "1":
    os.system("pip3 install cloudscraper")
    os.system("pip3 install socks")
    os.system("pip3 install pysocks")
    os.system("pip3 install colorama")
    os.system("pip3 install undetected_chromedriver")
    os.system("pip3 install httpx")
    os.system("pip3 install proxify")
    
## Install nodeJs module

    os.system("npm i cloudflare-bypasser")
    os.system("npm i axios")
    os.system("npm i cloudscraper")
    os.system("npm i crypto")
    os.system("npm i cluster")
    os.system("npm i user-agents")
    os.system("npm i user-agent")
    os.system("npm i tls")
    os.system("npm i set-cookie-parser")
    os.system("npm i requests")
    os.system("npm i request")
    os.system("npm i randomstring")
    os.system("npm i random-words")
    os.system("npm i random-useragent")
    os.system("npm i playwright")
    os.system("npm i net")
    os.system("npm i https")
    os.system("npm i http2")
    os.system("npm i http")
    os.system("npm i hcaptcha-solver")
    os.system("npm i gradient-string")
    os.system("npm i fs")
    os.system("npm i events")
    os.system("npm i crypto-random-string")
        

if os.name == "nt":
    pass
else:
    os.system("wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb")
    os.system("apt-get install ./google-chrome-stable_current_amd64.deb")

    os.system(f'wget https://sunny9577.github.io/proxy-scraper/proxies.txt')
    
    os.system(f'python3 GARSEC.py')